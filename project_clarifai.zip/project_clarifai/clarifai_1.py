from clarifai import rest
from clarifai.rest import ClarifaiApp
from clarifai.rest import Image as ClImage
import pprint
var={}
app = ClarifaiApp("kduAK47nde3QSpZmlcakcefyD0QOhnc4oZVMLys4", "20ZOnPa-_AY_sLzcYesRyMhtLjLULRx26tLjc3QJ")

model = app.models.get('bd367be194cf45149e75f01d59f77ba7')
inputfile=open("clarifai_images.txt","r")
outputfile=open("clarifai_images_score.txt","w")
k=0
for line in inputfile:
	if k>0:
		k+=1
		print k
		try:
			line=line.replace("\n","")
			allcontent=line.split("\t")
			name=allcontent[5]
			link=allcontent[6]
			image = ClImage(url=link)
			var= model.predict([image])
			#print var['data']
		#	for key in var:
		#	print key
		#	print var[key]
		#	print ("\n")
			data=var["outputs"]
		#	for i in range(len(data)):
		#	print i
		#	print data[i]
		#	print ("\n")
			
		#model.predict_by_url(url='https://static.pexels.com/phprint ("\n")otos/46239/salmon-dish-food-meal-46239.jpeg')
			print ("\n")
			outputfile.write(name+"\t"+link+"\t")
			array={}
			for i in range(len( data[0]["data"]["concepts"])):

				#print data[0]["data"]["concepts"][i]["name"]
				#print data[0]["data"]["concepts"][i]["value"]
				array.update({data[0]["data"]["concepts"][i]["name"]:data[0]["data"]["concepts"][i]["value"]})
			for key in array:
				outputfile.write(key+str(array[key])+" ")
			outputfile.write("\n")
		except:
			print("error")
			outputfile.write(name+"\t"+link+"\t"+"no tags")
			outputfile.write("\n")


	else:
		k+=1